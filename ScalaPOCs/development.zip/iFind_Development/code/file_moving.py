import sys,os,shutil
from optparse import OptionParser
from datetime import date, timedelta
from os import listdir


def main():

    source_dir = "/data/bdpd/bdh/01/landingzone/efgifi/"
    destination_dir= "/data/bdpt/bdh/01/landingzone/efgifi/"

    onlyfiles = [f for f in listdir(source_dir)]\

    for fileName in onlyfiles:
        print "Input File Name :["+fileName+"]"
        targetFileName=fileName
        targetFileName=targetFileName.upper()
        source_file_name=source_dir+fileName
        shutil.move(source_file_name,destination_dir+"/"+targetFileName)

if __name__ == "__main__":
    main()