import sys,os,shutil, datetime, time
from optparse import OptionParser
from datetime import date, timedelta


def main():

    global given_length,source_file, outputfile_name
    env, env_ver, given_length, source_file, outputfile_name, custom_date = arg_handle()

    home = '/data/'
    path = os.path.dirname(os.path.realpath(__file__))

    #env = path.split('/')[2].split('bdp')[1]
    #env_ver = path.split('/')[4]
    log_time = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d_%H-%M-%S')
    log_file =  "/data/bdp"+env+"/bdh/"+env_ver+"/efgifi/logs/run_lengh_correction" +'_'+ outputfile_name + '_' + log_time  + '.log'

    sys.stdout = open(log_file, "a",0)

    print("length_corrector.py           -> Input     given_length : " + str(given_length))
    print("length_corrector.py           -> Input     source_file : " + str())
    print("length_corrector.py           -> Input     outputfile_name : " + str(outputfile_name))
    print("lenght_corrector.py    -> Started      : " + datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S'))

    print "path" + path
    root = path.split('efgifi/')[0]
    print root

    formatDate=""
    if custom_date == None:
        todayDate = date.today()
        formatDate=datetime.datetime.strftime(todayDate, '%Y%m%d')
    else:
        todayDate = datetime.datetime.strptime(custom_date , '%Y%m%d')
        formatDate=datetime.datetime.strftime(todayDate, '%Y%m%d')

    #todayDate=date.today()
    #formatDate=datetime.datetime.strftime(todayDate, '%Y%m%d')
    landingzone = root+"/landingzone/efgifi"
    archive_dir= root+"/efgifi/wrk/archive"
    source_file=source_file.lower()+'_'+str(formatDate)
    print source_file

    file_length = os.path.getsize(landingzone+"/"+source_file)
    reminder = file_length % long(given_length)

    print "no of bytes to be removed" ,reminder
    required_file_length = file_length - reminder
    print "file length after the byte removal" ,required_file_length

    with open(landingzone+"/"+source_file, 'r') as fsrc:
        with open(landingzone+"/"+outputfile_name, 'w') as fdest:
            shutil.copyfileobj(fsrc, fdest)
            fdest.seek(-(reminder), os.SEEK_END)
            fdest.truncate()

    shutil.move(landingzone+"/"+source_file,archive_dir+"/"+source_file+"_"+log_time)
    print("lenght_corrector.py    -> Ended      : " + datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S'))

def arg_handle():
    usage = "usage: run_criss_index_generator_wf.py (options)"
    parser = OptionParser(usage)
    parser.add_option("-a", "--app", dest="app",
              help="application name")
    parser.add_option("-b", "--subapp", dest="subapp",
                  help="application name")
    parser.add_option("-g", "--group", dest="group",
                  help="job group name")
    parser.add_option("-e", "--env", dest="env",
              help="environment name")
    parser.add_option("-v", "--env_ver", dest="env_ver",
              help="environment name")
    parser.add_option("-l", "--op0", dest="given_length",
                  help="length of file")
    parser.add_option("-s", "--op1", dest="source_file",
                  help="source File name")
    parser.add_option("-o", "--op2", dest="outputfile_name",
                  help="Output File name")
    parser.add_option("-c", "--op3", dest="custom_date",
              help="Custom Date")

    (options, args) = parser.parse_args()
    print("length_corrector.py           -> Input      : " + str(options))

    sys.stdout.flush()
    return options.env, options.env_ver, options.given_length, options.source_file, options.outputfile_name, options.custom_date

if __name__ == "__main__":
    main()