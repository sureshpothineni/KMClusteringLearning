sh /data/bdpt/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "CCTPCPB.N.IFIND.STDFLD.DELIM(0)" PGHT bdh efgifi &
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "CCTPCPB.N.IFIND.DELIM(0)" PGHT bdh efgifi &
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "TOPPCPB.N.IFAMG.AFFEMP.EXTRACT(0)" PGHT bdh efgifi &
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "TOPPCPB.N.IFAMG.ACHTRAN(0)" PGHT bdh efgifi &
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "HRSPCPB.N.HRMS.GDG.PER29901.DAT(0)" PGHT bdh efgifi &
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "TELPCPB.N.GDG.BRANCH.DATA.ALL(0)" PGHT bdh efgifi &
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "TELPCPB.N.TIC.EXTRACT.TELOFFCK(0)" PGHT bdh efgifi &
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "EAIPCPB.N.GDG.TRL.DLY.ACCOUNT3(0)" PGHT bdh efgifi &