python /data/bdpt/bdh/01/efgifi/code/scripts/length_corrector.py --length 2000 --sourceFile CCTPCPB_N_IFIND_STDFLD_DELIM --outputFile criss_stdfld_delim
python /data/bdpt/bdh/01/efgifi/code/scripts/length_corrector.py --length 256 --sourceFile TOPPCPB_N_IFAMG_AFFEMP_EXTRACT --outputFile amg_affemp
python /data/bdpt/bdh/01/efgifi/code/scripts/length_corrector.py --length 256 --sourceFile TOPPCPB_N_IFAMG_ACHTRAN --outputFile amg_achtran
python /data/bdpt/bdh/01/efgifi/code/scripts/length_corrector.py --length 454 --sourceFile HRSPCPB_N_HRMS_GDG_PER29901_DAT --outputFile hr_per29901
python /data/bdpt/bdh/01/efgifi/code/scripts/length_corrector.py --length 1056 --sourceFile TELPCPB_N_GDG_BRANCH_DATA_ALL --outputFile ticofficial_branch
python /data/bdpt/bdh/01/efgifi/code/scripts/length_corrector.py --length 900 --sourceFile TELPCPB_N_TIC_EXTRACT_TELOFFCK --outputFile ticofficial_extract
python /data/bdpt/bdh/01/efgifi/code/scripts/length_corrector.py --length 760 --sourceFile EAIPCPB_N_GDG_TRL_DLY_ACCOUNT3 --outputFile acct

python /data/bdpt/bdh/01/global/code/scripts/run_job.py stdfld_mf_rawdb bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py stdfld_parquet_par bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py amg_affemp_mf_rawdb bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py amg_affemp_parquet_par bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py amg_achtran_mf_rawdb bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py amg_achtran_parquet_par bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py hr_mf_rawdb bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py hr_parquet_par bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py ticofficial_data_mf_rawdb bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py ticofficial_data_parquet_par bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py ticofficial_extract_mf_rawdb bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py ticofficial_extract_parquet_par bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py acct_mf_rawdb bdh efgifi
python /data/bdpt/bdh/01/global/code/scripts/run_job.py acct_parquet_par bdh efgifi

python /data/bdpt/bdh/01/global/code/scripts/run_job.py stdfld bdh efgifi

stdfld_load|g|length_corrector.py|2000|CCTPCPB_N_IFIND_STDFLD_DELIM|criss_stdfld
stdfld_load|g|file_ingest_rawdb.py|stdfld.properties

python /data/bdpt/bdh/01/global/code/scripts/run_job.py criss bdh efgifi

=============================

sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "CCTPCPB.N.IFIND.STDFLD.DELIM(0)" PGHT bdh efgifi
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "CCTPCPB.N.IFIND.DELIM(0)" PGHT bdh efgifi
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "TOPPCPB.N.IFAMG.AFFEMP.EXTRACT(0)" PGHT bdh efgifi
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "TOPPCPB.N.IFAMG.ACHTRAN(0)" PGHT bdh efgifi
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "HRSPCPB.N.HRMS.GDG.PER29901.DAT(0)" PGHT bdh efgifi
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "TELPCPB.N.GDG.BRANCH.DATA.ALL(0)" PGHT bdh efgifi
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "TELPCPB.N.TIC.EXTRACT.TELOFFCK(0)" PGHT bdh efgifi
sh /data/bdpq/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "EAIPCPB.N.GDG.TRL.DLY.ACCOUNT3(0)" PGHT bdh efgifi

python /data/bdpq/bdh/01/efgifi/code/scripts/length_corrector.py --length 2000 --sourceFile CCTPCPB_N_IFIND_STDFLD_DELIM --outputFile criss_stdfld
python /data/bdpq/bdh/01/efgifi/code/scripts/length_corrector.py --length 256 --sourceFile TOPPCPB_N_IFAMG_AFFEMP_EXTRACT --outputFile amg_affemp
python /data/bdpq/bdh/01/efgifi/code/scripts/length_corrector.py --length 256 --sourceFile TOPPCPB_N_IFAMG_ACHTRAN --outputFile amg_achtran
python /data/bdpq/bdh/01/efgifi/code/scripts/length_corrector.py --length 454 --sourceFile HRSPCPB_N_HRMS_GDG_PER29901_DAT --outputFile hr_per29901
python /data/bdpq/bdh/01/efgifi/code/scripts/length_corrector.py --length 1056 --sourceFile TELPCPB_N_GDG_BRANCH_DATA_ALL --outputFile ticofficial_branch
python /data/bdpq/bdh/01/efgifi/code/scripts/length_corrector.py --length 900 --sourceFile TELPCPB_N_TIC_EXTRACT_TELOFFCK --outputFile ticofficial_extract
python /data/bdpq/bdh/01/efgifi/code/scripts/length_corrector.py --length 760 --sourceFile EAIPCPB_N_GDG_TRL_DLY_ACCOUNT3 --outputFile acct

python /data/bdpq/bdh/01/global/code/scripts/run_job.py stdfld_mf_rawdb bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py stdfld_parquet_par bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py amg_affemp_mf_rawdb bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py amg_affemp_parquet_par bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py amg_achtran_mf_rawdb bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py amg_achtran_parquet_par bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py hr_mf_rawdb bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py hr_parquet_par bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py ticofficial_data_mf_rawdb bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py ticofficial_data_parquet_par bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py ticofficial_extract_mf_rawdb bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py ticofficial_extract_parquet_par bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py acct_mf_rawdb bdh efgifi
python /data/bdpq/bdh/01/global/code/scripts/run_job.py acct_parquet_par bdh efgifi


nohup sh /data/bdpq/bdh/01/efgifi/code/scripts/run_amg_affemp_jobs.sh&
nohup sh /data/bdpq/bdh/01/efgifi/code/scripts/run_amg_achtran_jobs.sh&
nohup sh /data/bdpq/bdh/01/efgifi/code/scripts/run_hr_jobs.sh&
nohup sh /data/bdpq/bdh/01/efgifi/code/scripts/run_stdfld_delim_jobs.sh&
nohup sh /data/bdpq/bdh/01/efgifi/code/scripts/run_ticofficial_branch_jobs.sh&
nohup sh /data/bdpq/bdh/01/efgifi/code/scripts/run_ticofficial_extract_jobs.sh&
nohup sh /data/bdpq/bdh/01/efgifi/code/scripts/run_acct_jobs.sh&
nohup sh /data/bdpq/bdh/01/efgifi/code/scripts/run_ifind_extract_jobs.sh&

nohup sh /data/bdpq/bdh/01/efgifi/code/scripts/run_ifind_delim_jobs.sh&

nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py stdfld_parquet_par bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py amg_affemp_parquet_par bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py amg_achtran_parquet_par bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py hr_parquet_par bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py ticofficial_data_parquet_par bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py ticofficial_extract_parquet_par bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py ifind_parquet_par bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py acct_parquet_par bdh efgifi&

nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py CIF_PNC_IMS_CUST2ACCT_ingest bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py CIF_PNC_IMS_CUSTOMER_ingest bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py DDA_PNC_HOGAN_MASTER_ingest bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py CIF_PNC_IMS_CUST2CUST_ingest bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py tda_pnc_extract_ingest bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py TELLER_TXN_DLY_ingest bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py view_itrust_ingest bdh efgifi&





nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI01 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI04 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI07 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI10 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI13 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI16 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI21 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI24 bdh efgifi&
BDHACI17 depends on BDHACI16
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI17 bdh efgifi&

nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI02 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI05 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI08 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI11 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI14 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI18 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI22 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI25 bdh efgifi&

nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI26 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI27 bdh efgifi&
nohup python /data/bdpq/bdh/01/global/code/scripts/run_job.py BDHACI28 bdh efgifi&
