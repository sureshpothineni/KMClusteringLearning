sh /data/bdpp/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "TOPPCPB.N.IFAMG.ACHTRAN(0)" PGHT bdh efgifi
