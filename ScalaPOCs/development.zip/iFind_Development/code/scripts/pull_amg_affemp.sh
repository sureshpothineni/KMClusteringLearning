sh /data/bdpp/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "TOPPCPB.N.IFAMG.AFFEMP.EXTRACT(0)" PGHT bdh efgifi
