sh /data/bdpp/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "HRSPCPB.N.HRMS.GDG.PER29901.DAT(0)" PGHT bdh efgifi
