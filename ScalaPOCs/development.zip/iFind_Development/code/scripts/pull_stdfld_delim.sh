sh /data/bdpp/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "CCTPCPB.N.IFIND.STDFLD.DELIM(0)" PGHT bdh efgifi
