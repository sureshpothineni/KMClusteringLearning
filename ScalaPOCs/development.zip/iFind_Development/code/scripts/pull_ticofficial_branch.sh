sh /data/bdpp/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "TELPCPB.N.GDG.BRANCH.DATA.ALL(0)" PGHT bdh efgifi
