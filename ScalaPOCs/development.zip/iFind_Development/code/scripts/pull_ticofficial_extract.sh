sh /data/bdpp/bdh/01/data_ingest/code/scripts/mainframe_Pull.sh "TELPCPB.N.TIC.EXTRACT.TELOFFCK(0)" PGHT bdh efgifi
