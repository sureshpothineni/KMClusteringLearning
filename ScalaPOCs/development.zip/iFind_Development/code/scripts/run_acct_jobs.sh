python /data/bdpp/bdh/01/efgifi/code/scripts/length_corrector.py --length 760 --sourceFile EAIPCPB_N_GDG_TRL_DLY_ACCOUNT3 --outputFile acct
python /data/bdpp/bdh/01/global/code/scripts/run_job.py acct_mf_rawdb bdh efgifi
