python /data/bdpp/bdh/01/efgifi/code/scripts/length_corrector.py --length 256 --sourceFile TOPPCPB_N_IFAMG_AFFEMP_EXTRACT --outputFile amg_affemp
python /data/bdpp/bdh/01/global/code/scripts/run_job.py amg_affemp_mf_rawdb bdh efgifi
