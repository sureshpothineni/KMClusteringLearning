python /data/bdpp/bdh/01/global/code/scripts/run_job.py $1 bdh efgifi
