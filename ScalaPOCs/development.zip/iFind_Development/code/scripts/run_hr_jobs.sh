python /data/bdpp/bdh/01/efgifi/code/scripts/length_corrector.py --length 454 --sourceFile HRSPCPB_N_HRMS_GDG_PER29901_DAT --outputFile hr_per29901
python /data/bdpp/bdh/01/global/code/scripts/run_job.py hr_mf_rawdb bdh efgifi
