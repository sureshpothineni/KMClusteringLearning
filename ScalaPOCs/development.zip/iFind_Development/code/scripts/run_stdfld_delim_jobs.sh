python /data/bdpp/bdh/01/efgifi/code/scripts/length_corrector.py --length 2000 --sourceFile CCTPCPB_N_IFIND_STDFLD_DELIM --outputFile criss_stdfld
python /data/bdpp/bdh/01/global/code/scripts/run_job.py stdfld_mf_rawdb bdh efgifi
