python /data/bdpp/bdh/01/efgifi/code/scripts/length_corrector.py --length 900 --sourceFile TELPCPB_N_TIC_EXTRACT_TELOFFCK --outputFile ticofficial_extract
python /data/bdpp/bdh/01/global/code/scripts/run_job.py ticofficial_extract_mf_rawdb bdh efgifi
