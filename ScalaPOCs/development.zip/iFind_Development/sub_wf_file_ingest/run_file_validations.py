#!/usr/bin/python

# Purpose: validation count script to collect record counts from source and hive
# Parameters : 
# 		hive db name
#		hive table name
#		Where clause
#               options file for sqoop 
#               jdbc connect string with database name
#               username for sqoop
#               password file for sqoop 
#               
import os
import sys
import commands
import time
import datetime
from optparse import OptionParser


def main():
    
    print("Python Script started at " + datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S') )

    global hv_db, table, hv_table, where,where_hadoop, options_file, jdbc_connect, username, password_alias, password_provider,hadoop_user, domain_name, impala_connect, default_queuename,hdfs_meta_raw,hv_db_meta_stage,group,hdfs_load_ts,partition_column
    hv_db, table, hv_table, where,where_hadoop, options_file, jdbc_connect, username, password_alias, password_provider,hadoop_user,domain_name, impala_connect,default_queuename,hdfs_meta_raw,hv_db_meta_stage,group,hdfs_load_ts,partition_column=arg_handle()
  
    global abc_log_file,hdfs_abc_log_file,asofdate,abc_line
    
    asofdate=datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d')

    cmd = "echo " + hadoop_user
    rcc,status_txt=commands.getstatusoutput(cmd)
    hadoop_user=status_txt.upper()


    abc_log_file = 'run_validations_'+ datetime.datetime.fromtimestamp(time.time()).strftime('%Y%m%d%H%M%S') 
    hdfs_abc_log_file = hdfs_meta_raw +"/"+ hv_db_meta_stage +"/abc_hadoop/load_date="+str(asofdate)+"/00000.log";

    abc_line = "|".join([group,"run_validations.py","python","run_oozie_workflow.py",hv_db +"."+hv_table,"where " + where ,"STARTED",
                         hadoop_user.lower(),"Started validating source and hadoop counts..." ,str(datetime.datetime.today())+"\n"])

    do_kinit() 
    writeabc(abc_line)

    rc,impala_cnt=run_impala_count()

  
    print('Impala record counts are ' + str(impala_cnt))

    rc,source_cnt=run_source_file_count()
    print('Source record counts are ' + str(source_cnt))  
    
  
    if impala_cnt != source_cnt :
       print('Both counts are not matching ...')
       abc_line = "|".join([group,"run_validations.py","python","run_oozie_workflow.py",hv_db +"."+hv_table,"where " + where,"FAILED",
                         hadoop_user.lower(),"SOURCE COUNTS :" + str(source_cnt) + " HADOOP COUNTS :" + str(impala_cnt),str(datetime.datetime.today())+"\n"])
       writeabc(abc_line)
       remove_keytab()
       sys.exit(-1)

    abc_line = "|".join([group,"run_validations.py","python","run_oozie_workflow.py",hv_db +"."+hv_table,"where " + where,"SUCCEEDED",
                         hadoop_user.lower(),"SOURCE COUNTS :" + str(source_cnt) + " HADOOP COUNTS :" + str(impala_cnt),str(datetime.datetime.today())+"\n"])
    writeabc(abc_line)
    remove_keytab()
    remove_abc_log()
    sys.exit()

def arg_handle():
    usage = "usage: run_ingest.py [options] "
    parser = OptionParser(usage)
    parser.add_option("-d","--hv_db", dest="hv_db",
                      help="Hive Database Name")
    parser.add_option("-b", "--table", dest="table",
                      help="Hive Table Name")
    parser.add_option("-t", "--hv_table", dest="hv_table",
                      help="Table Name")
    parser.add_option("-w", "--where", dest="where",
                      help="Where Clause for RDBMS")
    parser.add_option("-r", "--where_hadoop", dest="where_hadoop",
                      help="Where Clause for hadoop")
    parser.add_option("--options_file", dest="options_file",
                      help="options_file")
    parser.add_option("--jdbc_connect", dest="jdbc_connect",
                      help="jdbc connect string with database")
    parser.add_option("--username", dest="username",
                      help="username for source database")
    parser.add_option("--password-alias", dest="password_alias",
                      help="password alias for sqoop")
    parser.add_option("--password-provider", dest="password_provider",
                      help="password key provider for sqoop")
    parser.add_option("--hadoop_user", dest="hadoop_user",
                      help="Hadoop user who submitted the workflow.")
    parser.add_option("--domain_name", dest="domain_name",
                      help="domain name of Hadoop user who submitted the workflow.")
    parser.add_option("--impala_connect", dest="impala_connect",
                      help="connection to impala")
    parser.add_option("--default_queuename", dest="default_queuename",
                      help="default queue name")
    parser.add_option("--hdfs_meta_raw", dest="hdfs_meta_raw",
                      help="HDFS location for meta db")
    parser.add_option("--hv_db_meta_stage", dest="hv_db_meta_stage",
                      help="Hive meta raw database name ")
    parser.add_option("--group", dest="group",
                      help="group name for abc logging")
    parser.add_option("--hdfs_load_ts", dest="hdfs_load_ts",
                      help="HDFS LOAD TS for Final table querying")
    parser.add_option("--partition_column", dest="partition_column",
                      help="Column to Decide on Incremental or Full Compute Stats")
    (options, args) = parser.parse_args()

    return options.hv_db,options.table,options.hv_table,options.where,options.where_hadoop,options.options_file,options.jdbc_connect,options.username,options.password_alias,options.password_provider, options.hadoop_user, options.domain_name, options.impala_connect,options.default_queuename,options.hdfs_meta_raw,options.hv_db_meta_stage,options.group,options.hdfs_load_ts,options.partition_column

def do_kinit():
   cmd="rm " + hadoop_user +".keytab"
   rcc,status_txt=commands.getstatusoutput(cmd)
   print "removing old keytabs if any...status=", status_txt
   cmd="hdfs dfs -get /user/" + hadoop_user.lower() + "/" + hadoop_user + ".keytab"
   rcc,status_txt=commands.getstatusoutput(cmd)
   print "Getting keytab and status = ", status_txt

def remove_keytab():
   cmd="rm " + hadoop_user + ".keytab"
   rcc,status_txt=commands.getstatusoutput(cmd)

def remove_abc_log():
   cmd="rm " + abc_log_file
   rcc,status_txt=commands.getstatusoutput(cmd)


def run_impala_count():
    #Compute-Stats
    if(partition_column.strip()):        
        impala_compute_stats = 'compute incremental stats ' + hv_db + '.' + hv_table +';'
    else:
        impala_compute_stats = 'compute stats ' + hv_db + '.' + hv_table +';'
        
    # compute stats ' + hv_db + '.' + hv_table +' ; set sync_ddl = true; refresh
    impala_query='set sync_ddl = true; set REQUEST_POOL="' + default_queuename + '"'+ '; refresh ' + hv_db + '.' + hv_table +';' + impala_compute_stats + 'set REQUEST_POOL="' + default_queuename + '"'+ ';select count(*) from ' + hv_db + '.' + hv_table + ' where hdfs_load_ts=' + hdfs_load_ts +";"
    #impala_launch='impala-shell -V -i lbdp144a -k --ssl --quiet -B -q '   
    
        
    impala_cmd=impala_connect +' "' + impala_query +'" '
    
    print(" Impala command to be run is " + impala_cmd)
    
    kinit_cmd = "kinit " + hadoop_user + domain_name + " -k -t " +  hadoop_user + ".keytab"
    
    try:
       print "running kinit command ....-> ", kinit_cmd
       rcc,status_txt=commands.getstatusoutput(kinit_cmd )
       print "kinit status txt = ", status_txt 
       rc,rec_cnt_txt=commands.getstatusoutput(impala_cmd)
       rec_cnt=rec_cnt_txt.replace("|","").split('\n')[-1].strip()
       if rc != 0:
          print('Error executing Impala Count Query')
          sys.exit(-1)
    except:
       print('Error executing the query')       
        
    return rc,rec_cnt


def run_source_file_count():
    
    abc_table_cnt ='select parameters from (select rank() over(order by a.log_time desc) as rk,a.* from ' \
    + hv_db_meta_stage + '.abc_hadoop a where a.status=\'COUNT_RECORDED\' and a.table_name=\'' \
    + table.lower() +'\' and a.load_date=\'' + asofdate + '\') main where main.rk=1;'
    # compute stats ' + hv_db + '.' + hv_table +' ; set sync_ddl = true; refresh
    impala_query='set sync_ddl = true; set REQUEST_POOL="' + default_queuename + '"'+ '; refresh ' + hv_db_meta_stage + '.abc_hadoop;set REQUEST_POOL="' + default_queuename + '";'+ abc_table_cnt
    #impala_launch='impala-shell -V -i lbdp144a -k --ssl --quiet -B -q '
    impala_cmd=impala_connect +' "' + impala_query + '" '
    
    print(" Impala command to be run is " + impala_cmd)
    kinit_cmd = "kinit " + hadoop_user + domain_name + " -k -t " +  hadoop_user + ".keytab"
    
    try:
       print "running kinit command ....-> ", kinit_cmd
       rcc,status_txt=commands.getstatusoutput(kinit_cmd )
       print "kinit status txt = ", status_txt 
       rc,rec_cnt_txt=commands.getstatusoutput(impala_cmd)
       rec_cnt=rec_cnt_txt.replace("|","").split('\n')[-1].strip()
       if rc != 0:
          print('Error executing Impala Count Query')
          sys.exit(-1)
    except:
       print('Error executing the query')

    return rc,rec_cnt

def run_source_count():
    sqoop_query='select count(*) from ' + table + ' where ' + where 
    sqoop_eval_cmd= 'sqoop eval '\
                    + '-DHADOOP_CREDSTORE_PASSWORD=none -Dhadoop.security.credential.provider.path="' \
                    + password_provider +'\"' + ' --connect "'+ jdbc_connect  \
                    + '" --options-file ' + options_file \
                    + ' --username ' + username + ' --password-alias ' + password_alias  \
                    + ' --query "' + sqoop_query + '" '
    
    print( 'the sqoop command to be run is ' + sqoop_eval_cmd ) 
    try:
       rc,rec_cnt_txt=commands.getstatusoutput(sqoop_eval_cmd)
       if rc != 0:
          print('Error executing Source Count Query')
          print('--------------------')
          print(rec_cnt_txt)
          sys.exit(-1)
    except:
       print('Error executing the query')

    rec_cnt=rec_cnt_txt.replace("|","").split('\n')[-2].strip()
   
    return rc,rec_cnt

def writeabc(line):
    #ABC Logging Error Handling
    cnt = 0
    maxCnt=7
    global abc_hdfs_put
    abc_hdfs_put = " ".join(["hdfs","dfs","-appendToFile",abc_log_file,
         hdfs_abc_log_file]) 
    hdfs_chmod = "hdfs dfs -chmod -R 777 " + hdfs_abc_log_file 
    
    with open(abc_log_file, 'w') as myfile:
      myfile.write(line)
    chmod_abc = "chmod 777 "+abc_log_file
    rc, status = commands.getstatusoutput(chmod_abc)    
    rc, out = commands.getstatusoutput(hdfs_chmod)
    
    #ABC Logging Error Handling - Try 7 Times run
    while(cnt<=maxCnt):
        cnt+=1
        rc, status = commands.getstatusoutput(abc_hdfs_put)
        if (rc >0):
            print status
        else:
            print "run_job.py              -> ABC_log written : " + line
            msck_command = "hive -e "
            msck_command = msck_command + "'use "+ hv_db_meta_stage +"; msck repair table abc_hadoop;'"
            print "Running msck repair table command ..." 
            rc, status = commands.getstatusoutput(msck_command)
            print status
            impala_cmd='set sync_ddl = true; set REQUEST_POOL="' + default_queuename + '"'+ '; refresh ' + hv_db_meta_stage + '.abc_hadoop ;set REQUEST_POOL="' + default_queuename + '"'+ ';'
            impala_cmd=impala_connect +' "' + impala_cmd + '" '
            print "Impala Command -> " + impala_cmd
            rc, status = commands.getstatusoutput(impala_cmd)
            print status
            break
        
if __name__ == "__main__":
    main()
    

