'''
Created on Apr 14, 2017

@author: PL72282
'''
import commands,os,subprocess,sys
from optparse import OptionParser

def arg_handle():
    usage = "usage: run_criss_index_gen_wf.py (options)"
    parser = OptionParser(usage)
    parser.add_option ("--num-executors" ,"--numExec", dest="num_executors",
                      help="number of executors for spark job")
    parser.add_option ("--executor-memory" ,"--execMemory", dest="executor_memory",
                      help="executor memory for  for spark job")
    parser.add_option("--driver-memory", "--driverMemory", dest="driver_memory",
                      help="driver memory for spark job")
    parser.add_option("--criss-source", "--op0", dest="sourceFile",
                      help="criss source file")
    parser.add_option("--criss-mapping", "--op1", dest="mappingFile",
                      help="criss header mapping for Ifind")
    parser.add_option("--target-dir", "--op2", dest="outputDir",
                      help=" path for the flattened file")
    parser.add_option("--lookup-dir", "--op3", dest="lookupTable",
                      help="hive lookup table ")
    parser.add_option("--script", dest="script",
                   help="script name ")
    parser.add_option("--hadoop_user", dest="hadoop_user",
                   help="hadoop user who submitted the workflow.")
    parser.add_option("--domain_name", dest="domain_name",
                   help="domain name")
    (options, args) = parser.parse_args()
    print("run_spark_submit.py           -> Input      : " + str(options))
     
    return options.num_executors, options.executor_memory , options.driver_memory ,options.sourceFile, options.mappingFile, options.outputDir, options.lookupTable,options.script, options.hadoop_user,options.domain_name


def do_kinit(hadoop_user,domain_name):
    cmd="rm " + hadoop_user +".keytab"
    rcc,status_txt=commands.getstatusoutput(cmd)
    print "removing old keytabs if any...status=", status_txt,rcc
    cmd="hdfs dfs -get /user/" + hadoop_user.lower() + "/" + hadoop_user + ".keytab"
    rcc,status_txt=commands.getstatusoutput(cmd)
    print "Getting keytab and status = ",cmd, status_txt,rcc
    kinit_cmd = "kinit " + hadoop_user + domain_name + " -k -t " +  hadoop_user + ".keytab"
    print "running kinit command ....-> ", kinit_cmd
    rcc,status_txt=commands.getstatusoutput(kinit_cmd)
    print "kinit RC:"+str(rcc),status_txt





def invokeSparkSubmitCmd(num_executors,executor_memory,driver_memory,sourceFilePath,mappingFilePath,targetFilePath,lookupFilePath,script,hadoop_user,domain_name):
    

    spark_job = " ".join(["spark-submit",
                   "--master",
                   "yarn-cluster",
                   "--num-executors",
                   num_executors,
                   "--queue",
                   "root.bdh.med",
                   "--executor-memory",
                   executor_memory,
                   "--driver-memory",
                   driver_memory,
                   script,
		           "--criss-source",
                   sourceFilePath,
                   "--criss-mapping",
                    mappingFilePath,
                   "--target-dir",
                   targetFilePath,
                   "--lookup-dir",
                   lookupFilePath])
    print "spark command Initiating:  \n"+str(spark_job)
    call = subprocess.Popen(spark_job.split(' '),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    prev_line = ""
    count_repeats = 0
    while True:
       line = call.stdout.readline()
       if not line:
           break
       if prev_line != line.strip()[18:] or count_repeats > 100:
          print line.strip()
          sys.stdout.flush()
          prev_line =  line.strip()[18:]
          count_repeats = 0
       else:
          count_repeats = count_repeats + 1
    call.communicate()
    sys.exit(call.returncode)
        


def main():
    
 
    os.environ["SPARK_HOME"] = "/opt/cloudera/parcels/CDH/lib/spark"
   
    num_executors,executor_memory,driver_memory,sourceFilePath,mappingFilePath,targetFilePath,lookupFilePath,script,hadoop_user,domain_name = arg_handle()
    
    cmd = "echo " + hadoop_user
    rcc,status_txt=commands.getstatusoutput(cmd)
    hadoop_user=status_txt.upper()
    do_kinit(hadoop_user.upper(),domain_name)
    
    sparkSubmit = invokeSparkSubmitCmd(num_executors,executor_memory,driver_memory,sourceFilePath,mappingFilePath,targetFilePath,lookupFilePath,script,hadoop_user,domain_name)
        
if __name__ == "__main__":
    main()

