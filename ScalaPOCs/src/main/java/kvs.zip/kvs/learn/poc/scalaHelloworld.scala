package kvs.learn.poc

object scalaHelloworld {
  def main(args:Array[String]){
    println("Hello world scala");
  }
}